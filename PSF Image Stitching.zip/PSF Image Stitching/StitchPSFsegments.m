%% STITCHES PSF SEGMENT IMAGES TOGETHER
% Image Requisites:
% 1) The number of segment images should be a perfect square (same number
%    of images per row as per column for characterizing the full diffuser PSF)
%
% 2) There should be ~30-50% overlap between adjacent images
%
% 3) All image sizes should also be equal and square
%
% 4) The image filenames should contain the linear indices of each image (read LR-TB)

% Instantiate image data store.
PSFsegmentDir = fullfile('Demo','PSFSegments - 2x2cm Diffuser');
calibrationScene = imageDatastore(PSFsegmentDir);
sortFiles(calibrationScene);

% Initialize starting image variables. Each row of segment images has an
% anchor image at the first column index.
montage(calibrationScene.Files)
numImages = numel(calibrationScene.Files);
sampleImgType = readimage(calibrationScene, 1);
rowAnchor = mat2gray(readimage(calibrationScene, 1)); 
currIm = rowAnchor;

% Initialize variable to hold image sizes. Assumes all sensor image sizes
% are the same.
imageSize = size(rowAnchor);

% Initialize image tranformations as identity matrix.
tforms(numImages) = affine2d(eye(3));

% Make signal suppression pyramid for cross-correlation
[X,Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
quarter_pyramid = X.*Y;
pyramid = [[quarter_pyramid fliplr(quarter_pyramid(:,1:end-1))] ;...
          flipud([quarter_pyramid(1:end-1, :) fliplr(quarter_pyramid(1:end-1,1:end-1))])];
pyramid_center_peak = imageSize(1) * imageSize(2);

% Get transformation matrices for each image
for n = 2:numImages
    
    startNewRow = mod(n, sqrt(numImages)) == 1;
            
    % Set current image to the anchor image from previous row.
    if startNewRow
        currIm = rowAnchor;  
    end
    
    % load adjacent calibration image
    nextIm = mat2gray(readimage(calibrationScene,n));
    
    % Cross-correlate adjacent images and subtract suppression pyramid.
    IcXIn = xcorr2(currIm,nextIm);
    midpt2 = round(size(IcXIn,1)/2);
    xcorr_center_peak = IcXIn(midpt2,midpt2);
    scale = xcorr_center_peak/pyramid_center_peak;
    IcXIn = IcXIn - scale*pyramid;
    
    % Create transformation matrix based on cross-correlation peak 
    maximum = max(max(IcXIn));
    [delY, delX] = find(IcXIn == maximum);
    delY = delY-midpt2;
    delX = delX-midpt2;
    tforms(n).T = [1, 0, 0; 0, 1, 0; delX, delY, 1];
    
    if startNewRow
        rowAnchor = nextIm;
        tforms(n).T = tforms(n).T * tforms(n-sqrt(numImages)).T;
    else
       tforms(n).T = tforms(n).T * tforms(n-1).T; 
    end
    
    currIm = nextIm;

end


%% Code Citation:
% The following panoramic reconstruction code was inspired by Matlab's 
% Feature Based Panoramic Stitching Tutorial 

% Initialize the Panorama
for n = 1:numel(tforms)
    [xlim(n,:), ylim(n,:)] = outputLimits(tforms(n), [1 imageSize(2)], [1 imageSize(1)]);
end

% Find the minimum and maximum output limits
xMin = min([1; xlim(:)]);
xMax = max([imageSize(2); xlim(:)]);

yMin = min([1; ylim(:)]);
yMax = max([imageSize(1); ylim(:)]);

% Width and height of panorama.
width  = round(xMax - xMin);
height = round(yMax - yMin);

% Initialize the "empty" panorama.
panorama = zeros([height width], 'like', sampleImgType);

% Initialize blending operator.
blender = vision.AlphaBlender('Operation', 'Binary mask', ...
    'MaskSource', 'Input port');

% Create a 2-D spatial reference object defining the size of the panorama.
xLimits = [xMin xMax];
yLimits = [yMin yMax];
panoramaView = imref2d([height width], xLimits, yLimits);

% Create the panorama.
for n = 1:numImages
    
    I = readimage(calibrationScene, n);

    % Transform I into the panorama.
    warpedImage = imwarp(I, tforms(n), 'OutputView', panoramaView);

    % Generate a binary mask.
    mask = imwarp(true(size(I,1),size(I,2)), tforms(n), 'OutputView', panoramaView);

    % Overlay the warpedImage onto the panorama.
    panorama = step(blender, panorama, warpedImage, mask);
end
%% 

figure; imshow(panorama)
PSFpath = fullfile('Demo', 'PSFs', 'recon_PSF.tif');
imwrite(panorama, PSFpath);

function sortFiles(imdatastore)
%Sorts the images in the data store based on their linear index.
fileNames = imdatastore.Files;

str_suffix = regexp(fileNames,'\d*','match');
dub_suffix = str2double(cat(1,str_suffix{:}));

[~,ii] = sortrows(dub_suffix, size(dub_suffix, 2));
sortedFiles = fileNames(ii);
imdatastore.Files = sortedFiles;

end

