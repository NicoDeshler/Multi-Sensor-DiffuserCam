s_dim = 1; %Sensor dimension
d_dim = 3; %Diffuser dimension
maxRatio = d_dim/s_dim;

% Load PSFs
psfFolder = fullfile('Demo','PSFs');
stdPSF_fname = 'standard_PSF.tif';
rcnPSF_fname = 'recon_PSF.tif';
standard_PSF = imread(fullfile(psfFolder, stdPSF_fname));
recon_PSF = imread(fullfile(psfFolder, rcnPSF_fname));

% Resize Images
imageSize = min(size(standard_PSF),size(recon_PSF));
imgsize = imageSize(1);
sYXmin = round(((size(standard_PSF) - imageSize)+1)/2);
rYXmin = round(((size(recon_PSF) - imageSize)+1)/2);
standard_PSF = standard_PSF(sYXmin(1):sYXmin(1)+imageSize(1)-1, sYXmin(2):sYXmin(2)+imageSize(2)-1);
recon_PSF = recon_PSF(rYXmin(1):rYXmin(1)+imageSize(1)-1, rYXmin(2):rYXmin(2)+imageSize(2)-1);

% Overwrite unequal PSFs
imwrite(standard_PSF, fullfile(psfFolder,stdPSF_fname));
imwrite(recon_PSF, fullfile(psfFolder,rcnPSF_fname));

% Compute dot product between the reconstructed PSF and the standard PSF
% for increasing areas of overlap between both.
% In theory, the PSF segments corresponding to an axially centered
% illumination of the diffuser should have the same PSF. Areas beyond this
% region are subject to aberrations for the PSF reconstructed via stitching. 
s_pix = round(imgsize/maxRatio);
num_crops = round(imgsize/2*(1-1/maxRatio));
PSF_recon_quality = ones(num_crops, 2); 
for k = 1: num_crops 
    xymin = round((imgsize-s_pix)/2) - k;
    whdim = s_pix + 2*k;
    sqr = [xymin, xymin, whdim, whdim];
    ratio = whdim/(s_pix);
   
    std_PSF = imcrop(standard_PSF, sqr);
    rcn_PSF = imcrop(recon_PSF, sqr);
 
    PSF_Acorr = sum(std_PSF(:).*std_PSF(:));
    PSF_Xcorr = sum(std_PSF(:).*rcn_PSF(:));
    raw_metric = PSF_Xcorr / PSF_Acorr;
    
    PSF_recon_quality(k,:) = [ratio, raw_metric]; 
end

% Plot reconstruction quality metric.
figure;
plot(PSF_recon_quality(:,1), PSF_recon_quality(:,2), '-b')
title('PSF Reconstruction via Stitching')
xlabel('Diffuser Width / Sensor Width')
ylabel('xCorr / autoCorr')
axis([1 maxRatio 0 1])

