function mask = MSConfig_GetMask(tiling, slots, t_pix, s_pix, spc_pix)
%MSCONFIG returns a multi-sensor configuration from a database of grid-wise
%sensor placements.
% t_pix = total pixels in zemax analysis
% s_pix = sensor size dimensions in pixels
% spc_pix = sensor spacing dimensions in pixels

% Get binary tile configuration
T = getTiling(tiling, slots);

% Create binary pixel mask representing active sensor positions
mask = [];
temp_row = [];
pad = round(spc_pix/2);
active = padarray(ones(s_pix), pad, 0);
empty = padarray(zeros(s_pix), pad, 0);
for i = 1:slots
    for j = 1:slots
       if T(i,j) == 1
           temp_row = horzcat(temp_row, active);
       else 
           temp_row = horzcat(temp_row, empty);
       end
    end
   mask = vertcat(mask,temp_row);
   temp_row = [];
end

half_dif1 = floor((t_pix - size(mask))/2);
fill = max(half_dif1, 0);
mask = padarray(mask, max(fill,0), 0);

half_dif2 = floor((t_pix - size(mask))/2);
kill = abs(min(half_dif2, 0));
mask = imcrop(mask, [kill, t_pix]);
end


function T = getTiling(patn, slots)

T = zeros(slots);

switch patn
    case 'full'
        T = ones(slots);
    case 'checkered'
        T = invhilb(slots) < 0;
    case 'striped'
        for j = 1:slots
            if mod(j,2) == 0
                T(j,:) = 1;
            end
        end
    %{    
    case 'squares'
        tiling = ones(2);
        for j = 1:ceil(ms_slots/2)
            if mod(j,2)
                tiling = padarray(tiling, [1,1], 0, 'both');
            else
                tiling = padarray(tiling, [1,1], 1, 'both');
            end
        end
        %}
    case 'random'
        T = randi([0,1],slots);
    
    otherwise
        HandleError('Provided sensor tiling does not exist.')
end

if size(T,1) ~= slots 
    HandleError('Invalid sensor tiling. Must be a binary square matrix with size = array_dim.')
end
end
