function L2norm = ReconL2NormV2(recon_volume, source_voxels)

% Normalize Reconstructed Volume
recon_vec = recon_volume(:)/max(recon_volume(:));
recon_L2 = norm(recon_vec);

% Compute normalized intensity flux through aperture for each point source
z_hat = [0;0;1]; % Unit vector normal to sensor plane
R = source_voxels; 
R_dot = (sum((R.*R), 2));
R_hat = R./(R_dot.^(1/2)); 
% R_hat is a matrix of cartesian unit vectors 
% indicating the direction of each point source relative to the sensor's center

flux_vec = (R_hat*z_hat)./(R_dot); %  Proportiona intensity flux for each point
flux_vec = flux_vec/max(flux_vec); % Normalize intensity flux for all points
ref_L2 = norm(flux_vec);

% For a perfect reconstruction, the normalized volumetric irradiance vector
% (recon_vec) should have the same L2-Norm as the normalized flux vector.
% Thus their ratio will be equal to 1 
L2norm = recon_L2/ref_L2 - 1;
 
% Create true point source volume
source_vol = zeros(size(recon_volume));
source_vol(sub2ind(size(source_vol),...
            source_voxels(:,1), source_voxels(:,2), source_voxels(:,3))) = 1;

% Plot True Volume
figure
subplot(2,3,1);
im1 = squeeze(max(source_vol,[],3));
imagesc(im1);
hold on
axis image
colormap parula
set(gca,'fontSize',6)
axis off
title('True - XY')
hold off

subplot(2,3,2)
im2 = squeeze(max(source_vol,[],1));
imagesc(im2);
hold on    
%axis image
colormap parula
%colorbar
set(gca,'fontSize',8)
title('True - XZ')
axis off
hold off

subplot(2,3,3)
im3 = squeeze(max(source_vol,[],2));
imagesc(im3);
hold on
%axis image
colormap parula
%colorbar   
set(gca,'fontSize',8)
title('True - YZ')
axis off
hold off

subplot(2,3,4);
im1r = squeeze(max(recon_vec,[],3));
imagesc(im1r)

subplot(2,3,5);
im2r = squeeze(max(recon_vec,[],1));
imagesc(im2r)

subplot(2,3,6);
im3r = squeeze(max(recon_vec,[],2));
imagesc(im3r)


%{
%% PERFORM DIRECT SUBTRACTION OF TRUE-SOURCE VOLUME FROM RECON VOLUME FOR
COMPUTING L2-NORM
pix = size(recon_vol, 1);
depth = size(recon_vol, 3);

% Voxel error tolerance
latPad = 3;
zPad = 1;

for i = 1:size(source_voxels,1)
    voxXY = source_voxels(i,1:2);
    z = source_voxels(i,3);
    
    %Define pad index limits to prevent indexing beyond matrix dimensions
    xypadLo = voxXY - min(latPad, (voxXY - latPad));
    xypadHi = voxXY + min(latPad, (pix - voxXY));
    zpadLo = z - min(zPad, z-1); 
    zpadHi = z + min(zPad, depth - z);
    
    % Set volume voxels for true sources to 1
    source_vol(xypadLo(2):xypadHi(2), xypadLo(1):xypadHi(1), zpadLo:zpadHi) = 1;
end

% Subtract true volume from reconstructed volume to compute L2-Norm 
diff = (recon_vec - source_vol) > 0;
reconL2 = sum(diff(:));
refL2 = sum(recon_vec(:));

% L2-Norm metric presented as a ratio
L2norm = reconL2/refL2; 
%}

end
