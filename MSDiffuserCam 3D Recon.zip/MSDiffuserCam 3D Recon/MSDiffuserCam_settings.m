dtstamp = datestr(datetime('now'),'mm-dd-yyyy HH_MM_SS');
outdir = ['SimRecons\',dtstamp, '\'];
mkdir(outdir);

% Files and save folders
lensFile = 'C:\Users\Deshler\Documents\Zemax\Samples\DiffuserCam Setups\Reconstruction Testing Setups\5 x 5 cm sensor - 250 pixels.zmx';
resultsFolder = [outdir, 'Results\'];
workspaceFolder = [outdir, 'Workspaces\'];
mkdir(resultsFolder)
mkdir(workspaceFolder)

% Iteration parameters
source_num = 10*[1, 2, 3, 4, 5];
sensor_spacing = repmat(linspace(0,1/3,5)',[1,2]);
trials = 5;

% Zemax Analysis parameters
pix = [250, 250]; %Change this value to the output square matrix size of the analysis
z_slices = 20;

% DiffuserCam_main (3D-ADMM) settings pathname
reconConfig = 'DiffuserCam_settings.m';

% INPUT_FMT = [lensFile, output dim, z slices, sources, sensor spacing, makeStack, makeScene];
default = {lensFile, pix, z_slices, 1, 0, true, false};
specific = {};

    










