
%impulse_mat_file_name = 'example_psfs.mat';
%impulse_var_name = 'psf';
%impulse_mat_file_name = 'PSFzStack.mat';
%impulse_var_name = 'PSFzStack';

image_file = '';
%image_file = 'example_raw.png';
%image_file = 'std_measurement.png';
color_to_process = 'mono';  %'red','green','blue', or 'mono'. If raw file is mono, this is ignored
image_bias = 100;   %If camera has bias, subtract from measurement file. 
lateral_downsample = 1;  %factor to downsample impulse stack laterally. Must be multiple of 2 and >= 1.
axial_downsample = 1;  % Axial averageing of impulse stack. Must be multiple of 2 and >= 1.
 
% Allow user to use subset of Z. This is computed BEFORE downsampling by a
% factor of AXIAL_DOWNSAMPLE
start_z = 1;  %First plane to reconstruct. 1 indexed, as is tradition.
end_z = 0;   %Last plane to reconstruct. If set to 0, use last plane in file.
 
 
% Populate solver options
 
% Solver parameters
solverSettings.tau = .000600;    %sparsity parameter for TV
solverSettings.tau_n = .0400;     %sparsity param for native sparsity
solverSettings.mu1 = 1;    %Initialize ADMM tuning params. If autotune is on, these will change
solverSettings.mu2 = 1;
solverSettings.mu3 = 1;
 
% if set to 1, auto-find mu1, mu2, mu3 every step. If set to 0, use user defined values. If set to N>1, tune for N steps then stop.
solverSettings.autotune = 1;    % default: 1
solverSettings.mu_inc = 1.1;   
solverSettings.mu_dec = 1.1;  %Increment and decrement values for mu during autotune. Turn to 1 to have no tuning.
solverSettings.resid_tol = 1.5;   % Primal/dual gap tolerance. Lower means more frequent tuning
solverSettings.maxIter = 100; % Maximum iteration count  Default: 200
solverSettings.regularizer = 'native';   %'TV' for 3D TV, 'native' for native. Default: TV
 
%Figures and user info
solverSettings.disp_percentile = 99.9;   %Percentile of max to set image scaling
solverSettings.save_every = 0;   %Save image stack as .mat every N iterations. Use 0 to never save (except for at the end);
if solverSettings.save_every
    warning(' save_every is not enabled yet. Your result will only be saved at the end of processing.')
end
%Folder for saving state. If it doesn't exist, create it. 
solverSettings.save_dir = '../DiffuserCamResults/demo';
% Strip / from path if used
 
solverSettings.disp_func = @(x)x;  %Function handle to modify image before display. No change to data, just for display purposes
solverSettings.disp_figs = 1;   %If set to 0, never display. If set to N>=1, show every N.
solverSettings.print_interval = 1;  %Print cost every N iterations. Default 1. If set to 0, don't print.
fig_num = 1;   %Figure number to display in


