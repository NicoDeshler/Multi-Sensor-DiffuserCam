function [varargout] = MSConfig(args)

% Initialize the OpticStudio connection
TheApplication = InitConnection();
if isempty(TheApplication)
    % failed to initialize a connection
    varargout = {};
else
    try
        [varargout] = BeginApplication(TheApplication, args);
        CleanupConnection(TheApplication);
    catch err
        CleanupConnection(TheApplication);
        rethrow(err);
    end
end
end

function app = InitConnection()

import System.Reflection.*;

% Find the installed version of OpticStudio.

% This method assumes the helper dll is in the .m file directory.
% p = mfilename('fullpath');
% [path] = fileparts(p);
% p = strcat(path, '\', 'ZOSAPI_NetHelper.dll' );
% NET.addAssembly(p);

% This uses a hard-coded path to OpticStudio
NET.addAssembly('C:\Users\Deshler\Documents\Zemax\ZOS-API\Libraries\ZOSAPI_NetHelper.dll'); 
success = ZOSAPI_NetHelper.ZOSAPI_Initializer.Initialize();
% Note -- uncomment the following line to use a custom initialization path
% success = ZOSAPI_NetHelper.ZOSAPI_Initializer.Initialize('C:\Program Files\OpticStudio\');
if success == 1
    LogMessage(strcat('Found OpticStudio at: ', char(ZOSAPI_NetHelper.ZOSAPI_Initializer.GetZemaxDirectory())));
else
    app = [];
    return;
end

% Now load the ZOS-API assemblies
NET.addAssembly(AssemblyName('ZOSAPI_Interfaces'));
NET.addAssembly(AssemblyName('ZOSAPI'));

% Create the initial connection class
TheConnection = ZOSAPI.ZOSAPI_Connection();

% Attempt to create a Standalone connection

% NOTE - if this fails with a message like 'Unable to load one or more of
% the requested types', it is usually caused by try to connect to a 32-bit
% version of OpticStudio from a 64-bit version of MATLAB (or vice-versa).
% This is an issue with how MATLAB interfaces with .NET, and the only
% current workaround is to use 32- or 64-bit versions of both applications.
app = TheConnection.CreateNewApplication();
if isempty(app)
   HandleError('An unknown connection error occurred!');
end
if ~app.IsValidLicenseForAPI
    HandleError('License check failed!');
    app = [];
end
end


%% Boilerplate Code
% NOTE: The abreviation ILU stands for "In Lens Units" and refers to the
% units of measurement used in the .zmx lens file.
function [varargout] = BeginApplication(TheApplication, args)
import ZOSAPI.*;

% OpticStudio session variables
TheSystem = TheApplication.PrimarySystem;
TheAnalyses = TheApplication.PrimarySystem.Analyses;
TheLDE = TheSystem.LDE;
SysData = TheSystem.SystemData.Fields;

% ARGS_INPUT_FMT = [(1)lensFile, (2)output dim, (3)z slices, (4)sources, (5)sensor spacing, (6)makeStack, (7)makeScene];

% Load in .zmx lens file from provided filepath
lensFile = args{1};
load_success = TheSystem.LoadFile(lensFile, false);
if load_success == false
    HandleError('The lens file failed to load. Check provided file path.')
end

% Surfaces
s1 = TheLDE.GetSurfaceAt(1);    % Point Source to Diffuser spacing
s2 = TheLDE.GetSurfaceAt(2);    % System Aperture
s3 = TheLDE.GetSurfaceAt(3);    % Diffuser surface

% Fields
f1 = SysData.GetField(1);

% Zemax Analysis
geom = TheAnalyses.New_Analysis_SettingsFirst(ZOSAPI.Analysis.AnalysisIDM.GeometricImageAnalysis);

% Sensor array specifications
% D_DIM       -   Geometric image analysis image size
% D_PIX       -   Output matrix size of Zemax analysis results
% S_DIM       -   Size of each sensor (ILU)
% SPC_DIM     -   Spacing between sensors (ILU)
% SLOTS       -   Number of sensor positions per row in multi-sensor array
% MS_CFG      -   Binary matrix indicating sensor array configuration
     
d_dim = 2*[s3.ApertureData.CurrentTypeSettings.XHalfWidth,...
            s3.ApertureData.CurrentTypeSettings.YHalfWidth];
d_pix = args{2};
u2pix = @(x)round(d_pix ./ d_dim .* x);  % Convert lens unit dimensions to pixels

% DiffuserCam reconstruction volume
FOV = pi/3;     % angular FOV in radians
DOFmax = 12;    % ILU
DOFmin = 2;     % ILU
DOFrange = DOFmax - DOFmin;

% PSF zstack calibration source positions
start_xyz = [0,0,DOFmin];
end_xyz = [0,0, DOFmax];
num_slices = args{3};
num_sources = args{4};

% Sensor configuration parameters
s_dim = [1,1];      % ILU
spc_dim = args{5};  % ILU
slots = 4;
s_pix = u2pix(s_dim);
spc_pix = u2pix(spc_dim);
cfg = 'full';   %OPTIONS: 'full', 'checkered', 'striped', 'random'

% Functionality execution booleans
makeStack = args{6};
makeScene = args{7};

% Set System Aperture (Default = 85% of the emulated single sensor dimensions)
emulDim = slots*(s_dim + spc_dim) - spc_dim; 
pA = 0.85; % Percent aperture 
Rect_Aper = s2.ApertureData.CreateApertureTypeSettings(ZOSAPI.Editors.LDE.SurfaceApertureTypes.RectangularAperture);
Rect_Aper.S_RectangularAperture_.XHalfWidth = pA*emulDim(1,1)/2;
Rect_Aper.S_RectangularAperture_.YHalfWidth = pA*emulDim(1,2)/2;
s2.ApertureData.ChangeApertureTypeSettings(Rect_Aper);

%{
% Analysis Settings - (UNCOMMENT TO ADJUST SETTINGS IN CODE) 
% NOTE: More settings are adjustable through the OpticStudio UI. 
cfgFile = 'C:\Users\Deshler\Documents\Zemax\Samples\DiffuserCam Setups\DOF v Sensor Size Experiment Setups\5 x 5 cm sensor.CFG';
geomSettings = geom.GetSettings();


%IMA_FIELD      -   The field size
%IMA_IMAGESIZE  -   The image size
%IMA_IMANAME    -   The image file name
%IMA_NA         -   The numerical aperture
%IMA_KRAYS      -   The number of rays x 1000
%IMA_OUTNAME    -   The output file name
%IMA_SURFACE    -   The surface number

geomSettings.ModifySettings(cfgFile, 'IMA_FIELD', '0');
geomSettings.ModifySettings(cfgFile, 'IMA_IMAGSIZE', int2str(d_dim));
geomSettings.ModifySettings(cfgFile, 'IMA_NAME', 'circle');
geomSettings.ModifySettings(cfgFile, 'IMA_KRAYS', '5000');
%}

if makeStack
    PSFzStack = GeneratePSFstack(start_xyz, end_xyz, num_slices);
    varargout{1:nargout} = {PSFzStack};
    %PSFzStack = stretchContrast(PSFzStack);
       
end

if makeScene
    [measurement, sources_xyz, sources_vox] = GenerateScene();
    % measurement = stretchContrast(measurement);   
    % Function handle for applying the sensor configuration mask
    applyMask = @(mask, stack) stack.*MSConfig_GetMask(mask, slots, d_pix, s_pix, spc_pix);
    ms_measurement = applyMask(cfg, measurement);
    
    varargout{1:nargout} = {measurement, ms_measurement, sources_xyz, sources_vox};
end

%% Functions for generating PSF stack and simulated scenes
    
    function stack = GeneratePSFstack(start_xyz, end_xyz, n)
    % Point source translates from START_XYZ coordinate to END_XYZ coordinate
    % in N steps while CURR_XYZ tracks the immediate position of the source.
    % Hence, only linear trajectories for the point source are possible.
    stack = zeros([d_pix, n]);
    curr_xyz = start_xyz;
    step_vec = (end_xyz - start_xyz)/(n-1); 

    for pos = 1:n
        % Set lateral and axial position of point source
        f1.X = curr_xyz(1);
        f1.Y = curr_xyz(2);
        s1.Thickness = curr_xyz(3);
        
        % Run the Geometric Image Analysis
        geom.ApplyAndWaitForCompletion();
        geom_results = geom.GetResults();
        geom_grid = geom_results.GetDataGrid(0);
        geom_data = geom_grid.Values.double;
        
        % Add PSF at current z to stack
        stack(:,:,pos) = geom_data;

        % Increment Point Source position
        curr_xyz = curr_xyz + step_vec;
    end

    end

    function [measurement, sources_xyz, sources_vox] = GenerateScene()
    % Simulate a measurement generated by randomly arranging M point sources.
   
    % Cartesian coordinates for point sources
    sources_xyz = rand(num_sources, 3);
    sources_xyz(:,3) = (sources_xyz(:,3)* DOFrange)+ DOFmin;                               % z coords
    sources_xyz(:,1:2) = (sources_xyz(:,3)* tan(FOV/2)).*(2*(sources_xyz(:,1:2)-(1/2)));   % x and y coords
    
    % Voxel coordinates for point sources
    sources_vox = zeros(size(sources_xyz));
    %sources_vox(:,1:2) = round((d_pix/(2*tan(FOV/2)))*(sources_vox(:,1:2)./sources_vox(:,3))); % x and y voxels
    InvFitScaleFact = @(z)(-123.24)./(z+1.6)+3.4;
    sfacts = InvFitScaleFact(sources_xyz(:,3));
    sources_vox(:,1:2) = round([sfacts.*sources_xyz(:,1), sfacts.*sources_xyz(:,2)]);
    
    if DOFrange == 0                                                                           % z voxels
        sources_vox(:,3) = 0;
    else
        sources_vox(:,3) = ceil((sources_xyz(:,3)- DOFmin) * (num_slices / DOFrange));
    end
    
    % Display point source locations
    figure;
    subplot(1,2,1)
    scatter3(sources_xyz(:,1), sources_xyz(:,2), sources_xyz(:,3));
    xlabel('x (cm)'); ylabel('y (cm)'); zlabel('z (cm)');
    latLimits = [-DOFmax*tan(FOV/2),DOFmax*tan(FOV/2)];
    axLimits = [latLimits, latLimits, DOFmin, DOFmax];
    axis(axLimits)
    
    subplot(1,2,2)
    scatter3(sources_vox(:,1), sources_vox(:,2), sources_vox(:,3));
    xlabel('x (voxels)'); ylabel('y (voxels)'); zlabel('z (voxels)');
    latLimits = round(d_pix/2).*[-1,1];
    axLimits = [latLimits, latLimits, 1, num_slices];
    axis(axLimits)
    
    measurement = zeros(d_pix);
    
    for ps = transpose(sources_xyz) 

        % Set lateral and axial position for point source
        f1.X = ps(1);
        f1.Y = ps(2);
        s1.Thickness = ps(3);

        % Run the Geometric Image Analysis
        geom.ApplyAndWaitForCompletion();
        geom_results = geom.GetResults();
        geom_grid = geom_results.GetDataGrid(0);
        geom_data = geom_grid.Values.double;

        measurement = measurement + geom_data;
    end
    
    end
        
end



function LogMessage(msg)
disp(msg);
end

function HandleError(error)
ME = MXException(error);
throw(ME);
end

function  CleanupConnection(TheApplication)
% Note - this will close down the connection.
% If you want to keep the application open, you should skip this step
% and store the instance somewhere instead.
TheApplication.CloseApplication();
end
