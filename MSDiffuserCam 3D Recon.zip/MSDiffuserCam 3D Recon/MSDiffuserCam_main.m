function MSDiffuserCam_main(config)
% Read in settings
run(config) %This should be a string path to a .m script that populates a several variables in your workspace

if ~isempty(specific)
    [PSFzStack, ms_measurement, std_measurement, sources_vox] = MSConfig(specific);
    ms_recon_volume = DiffuserCam_main(PSFzStack, ms_measurement);
    L2Norm = Vol_Recon_L2Norm(ms_recon_volume, sources_vox, 'default');
end

out_dims = [size(source_num,2), size(sensor_spacing,1), trials];
ms_performance_metric = zeros(out_dims); % Data Cube: X-Sensor Spacing, Y-Source Number, Z-Trials 
std_performance_metric = zeros(out_dims);
count = 1;

%f = zeros(trials,2);
try
    for s = 1:size(sensor_spacing,1)
        
        % Get PSF Stack
        PSFzStack = MSConfig(default);
        save([workspaceFolder, sprintf('PSFzStack_%d.mat', s)], 'PSFzStack')
        
        for n = 1:size(source_num,2)
            for t = 1:trials
                
                % Create a random scene and run the Zemax analysis
                % INPUT FORMAT = [lensFile, output dim, z slices, sources, sensor spacing, makeStack, makeScene];
                iterInput = {lensFile, pix, z_slices, source_num(1,n), sensor_spacing(s,:), false, true};
                [std_measurement, ms_measurement, sources_xyz, sources_vox] = MSConfig(iterInput);
                
                % Write sensor measurements to png files. Compatible format for
                % DiffuserCam_settings file read in.
                imwrite(std_measurement, [workspaceFolder, 'std_measurement.png'])
                imwrite(ms_measurement, [workspaceFolder, 'ms_measurement.png'])
                fprintf('MultiSensor and standard reconstructions in progress... Iteration %d out of %d.  \n',...
                        count, prod(out_dims))                    

                % Run the reconstruction
                std_recon_volume = DiffuserCam_main('DiffuserCam_settings.m', PSFzStack, [workspaceFolder, 'std_measurement.png']);
                ms_recon_volume = DiffuserCam_main('DiffuserCam_settings.m', PSFzStack, [workspaceFolder, 'ms_measurement.png']);

                % Crop zero-pad from recon volume layers
                [height, width, ~] = size(ms_recon_volume);
                std_trim = zeros([pix, z_slices]); 
                ms_trim = zeros([pix, z_slices]);
                for z = 1:z_slices
                    std_trim(:,:,z) = imcrop(std_recon_volume(:,:,z), [round(([height, width] - pix)/2), pix-1]);
                    ms_trim(:,:,z) = imcrop(ms_recon_volume(:,:,z), [round(([height, width] - pix)/2), pix-1]);
                end
                std_recon_volume =  std_trim;
                ms_recon_volume = ms_trim;
                
                % Shift lateral components of source voxels to make
                % point source coordinates in voxel space non-negative
                sources_vox(:,1:2) = sources_vox(:,1:2) + round(pix/2);

                % Compute the L2-Norm for reconstruction
                std_L2norm = ReconL2NormV2(std_recon_volume, sources_vox); 
                ms_L2norm = ReconL2NormV2(ms_recon_volume, sources_vox);
                
                % Store L2-Norm in performance metric data matrix
                std_performance_metric(n, s, t) = std_L2norm;
                ms_performance_metric(n, s, t) = ms_L2norm;

                close all 
                
                %{
                %% XYZ TO VOXEL CONVERSION FACTOR FITTING                
                [y,x,z] = ind2sub(size(ms_recon_volume),find(ms_recon_volume == max(max(max(ms_recon_volume)))));
                recon_xyz = [x-round(pix/2),y-round(pix/2),z];  
                
                factors = recon_xyz./sources_xyz;
                f(count,1) = sources_xyz(1,3);
                f(count,2) = mean(factors(1,1:2));
                %}
                count = count + 1;
                
            end
        end
    end
catch ME
    % Save workspace in case of error (e.g. Second Zemax session is opened during scene reconstruction)
    save([resultsFolder,sprintf('WorkspaceSavedOnErr%d',count)])
    rethrow(ME)
end

% Save recon performance data
save([resultsFolder,'Reconstruction_Performance_Data.mat'], 'std_performance_metric','ms_performance_metric')

X = sensor_spacing(:,1);
Y = source_num;

% Plot Single-Sensor recon performance results (Sensor spacing does not apply)
Z1 = mean(std_performance_metric, 3); %Average over all trials
figs(1) = figure; bar3(Z1);
title('Single Sensor Reconstruction L2-Norm')
xlabel('Effective Sensor Size (cm)');
xticklabels(X*3+4);
ylabel('Number of Sources');
yticklabels(Y);
zlabel('L2 Norm');


% Plot Multi-Sensor recon performance results
Z2 = mean(ms_performance_metric, 3); %Average over all trials
figs(2) = figure; bar3(Z2);
title('Multi-Sensor Reconstruction L2-Norm (1cm x 1cm sensors)')
xlabel('Sensor Spacing (cm)');
xticklabels(X);
ylabel('Number of Sources');
yticklabels(Y);
zlabel('L2 Norm');

% Plot recon performance difference
delZ = Z2-Z1;
figs(3) = figure; bar3(delZ);
title('Recon Performance Difference')
xlabel('Effective Sensor Size (cm)')
xticklabels
xticklabels(X*3+4);
ylabel('Number of Sources');
yticklabels(Y);
zlabel('\Delta L2 Norm');

savefig(figs, [resultsFolder, 'ReconDataBarGraphs.fig'])
end

